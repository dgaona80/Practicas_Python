"""
Paso 1: Generar CSVs de ejemplo para la guía de Great Expectations
"""
import pandas as pd
import numpy as np
from datetime import datetime, timedelta
import random

np.random.seed(42)

# ─────────────────────────────────────────────
# Dataset 1: Ventas de e-commerce (limpio)
# ─────────────────────────────────────────────
n = 500
start_date = datetime(2024, 1, 1)
dates = [start_date + timedelta(days=random.randint(0, 365)) for _ in range(n)]

ventas_limpio = pd.DataFrame({
    "order_id":      [f"ORD-{i:05d}" for i in range(1, n+1)],
    "customer_id":   [f"CUST-{random.randint(1000, 9999)}" for _ in range(n)],
    "product_name":  np.random.choice(["Laptop", "Teclado", "Mouse", "Monitor", "Audífonos", "Webcam"], n),
    "category":      np.random.choice(["Electronics", "Accessories", "Peripherals"], n),
    "price":         np.round(np.random.uniform(15.0, 2500.0, n), 2),
    "quantity":      np.random.randint(1, 10, n),
    "order_date":    [d.strftime("%Y-%m-%d") for d in dates],
    "status":        np.random.choice(["completed", "pending", "cancelled", "shipped"], n, p=[0.6, 0.2, 0.1, 0.1]),
    "customer_email":[f"user{random.randint(100,9999)}@example.com" for _ in range(n)],
    "rating":        np.random.choice([1,2,3,4,5], n, p=[0.05,0.05,0.15,0.35,0.40]),
})
ventas_limpio.to_csv("/home/claude/ge_guide/data/ventas_limpio.csv", index=False)
print("✅ ventas_limpio.csv generado:", ventas_limpio.shape)

# ─────────────────────────────────────────────
# Dataset 2: Ventas con problemas de calidad
# ─────────────────────────────────────────────
ventas_dirty = ventas_limpio.copy()

# Inyectar problemas
idx_null      = np.random.choice(n, 30, replace=False)
idx_neg_price = np.random.choice(n, 15, replace=False)
idx_bad_email = np.random.choice(n, 20, replace=False)
idx_bad_cat   = np.random.choice(n, 10, replace=False)
idx_bad_rating= np.random.choice(n, 8,  replace=False)
idx_dup       = np.random.choice(n, 5,  replace=False)

ventas_dirty.loc[idx_null, "customer_id"] = None
ventas_dirty.loc[idx_neg_price, "price"] = -abs(ventas_dirty.loc[idx_neg_price, "price"])
ventas_dirty.loc[idx_bad_email, "customer_email"] = "email_invalido_sin_arroba"
ventas_dirty.loc[idx_bad_cat, "category"] = "UNKNOWN_CATEGORY"
ventas_dirty.loc[idx_bad_rating, "rating"] = 99
# Duplicados
ventas_dirty = pd.concat([ventas_dirty, ventas_dirty.iloc[idx_dup]], ignore_index=True)

ventas_dirty.to_csv("/home/claude/ge_guide/data/ventas_sucios.csv", index=False)
print("✅ ventas_sucios.csv generado:", ventas_dirty.shape)

# ─────────────────────────────────────────────
# Dataset 3: Usuarios / CRM
# ─────────────────────────────────────────────
m = 300
users = pd.DataFrame({
    "user_id":    range(1, m+1),
    "first_name": np.random.choice(["Ana","Luis","María","Carlos","Elena","Jorge","Sofía"], m),
    "last_name":  np.random.choice(["García","López","Martínez","Hernández","Díaz"], m),
    "age":        np.random.randint(18, 75, m),
    "country":    np.random.choice(["México","Colombia","España","Argentina","Chile"], m, p=[0.4,0.2,0.2,0.1,0.1]),
    "signup_date":[( datetime(2020,1,1) + timedelta(days=random.randint(0,1460)) ).strftime("%Y-%m-%d") for _ in range(m)],
    "plan":       np.random.choice(["free","basic","pro","enterprise"], m, p=[0.5,0.25,0.15,0.10]),
    "monthly_spend": np.round(np.random.exponential(50, m), 2),
    "is_active":  np.random.choice([True, False], m, p=[0.8, 0.2]),
    "nps_score":  np.random.randint(0, 11, m),
})
users.to_csv("/home/claude/ge_guide/data/usuarios.csv", index=False)
print("✅ usuarios.csv generado:", users.shape)

print("\n📁 Archivos generados en /home/claude/ge_guide/data/")
