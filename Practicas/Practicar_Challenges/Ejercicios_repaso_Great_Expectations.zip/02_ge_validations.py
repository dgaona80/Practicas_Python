import json, copy, warnings
import pandas as pd
import numpy as np
import great_expectations as gx
from great_expectations import expectations as gxe

warnings.filterwarnings("ignore")

context = gx.get_context(mode="ephemeral")
df_clean = pd.read_csv("/home/claude/ge_guide/data/ventas_limpio.csv")
df_dirty = pd.read_csv("/home/claude/ge_guide/data/ventas_sucios.csv")
df_users = pd.read_csv("/home/claude/ge_guide/data/usuarios.csv")

_uid = [0]
def new_uid():
    _uid[0] += 1
    return _uid[0]

def run_suite(df, exp_factories):
    n = new_uid()
    ds    = context.data_sources.add_pandas(name=f"ds{n}")
    da    = ds.add_dataframe_asset(name=f"da{n}")
    bd    = da.add_batch_definition_whole_dataframe(f"bd{n}")
    suite = context.suites.add(gx.ExpectationSuite(name=f"suite{n}"))
    for factory in exp_factories:
        suite.add_expectation(factory())          # fresh instance each time
    vd = context.validation_definitions.add(
        gx.ValidationDefinition(name=f"vd{n}", data=bd, suite=suite))
    return vd.run(batch_parameters={"dataframe": df})

# ─── Factories: funciones lambda que crean instancias nuevas ─
def ventas_exp_factories():
    return [
        lambda: gxe.ExpectTableColumnsToMatchOrderedList(column_list=[
            "order_id","customer_id","product_name","category","price",
            "quantity","order_date","status","customer_email","rating"]),
        lambda: gxe.ExpectTableRowCountToBeBetween(min_value=400, max_value=600),
        lambda: gxe.ExpectColumnValuesToNotBeNull(column="order_id"),
        lambda: gxe.ExpectColumnValuesToNotBeNull(column="price"),
        lambda: gxe.ExpectColumnValuesToNotBeNull(column="quantity"),
        lambda: gxe.ExpectColumnValuesToNotBeNull(column="order_date"),
        lambda: gxe.ExpectColumnValuesToBeBetween(column="price",    min_value=0,   max_value=10000),
        lambda: gxe.ExpectColumnValuesToBeBetween(column="quantity", min_value=1,   max_value=50),
        lambda: gxe.ExpectColumnValuesToBeBetween(column="rating",   min_value=1,   max_value=5),
        lambda: gxe.ExpectColumnValuesToBeInSet(column="status",
            value_set=["completed","pending","cancelled","shipped"]),
        lambda: gxe.ExpectColumnValuesToBeInSet(column="category",
            value_set=["Electronics","Accessories","Peripherals"]),
        lambda: gxe.ExpectColumnValuesToBeUnique(column="order_id"),
        lambda: gxe.ExpectColumnValuesToMatchRegex(column="customer_email",
            regex=r"^[a-zA-Z0-9._%+\-]+@[a-zA-Z0-9.\-]+\.[a-zA-Z]{2,}$"),
    ]

def users_exp_factories():
    return [
        lambda: gxe.ExpectTableRowCountToBeBetween(min_value=200, max_value=400),
        lambda: gxe.ExpectColumnValuesToNotBeNull(column="user_id"),
        lambda: gxe.ExpectColumnValuesToBeUnique(column="user_id"),
        lambda: gxe.ExpectColumnValuesToBeBetween(column="age", min_value=18, max_value=120),
        lambda: gxe.ExpectColumnValuesToBeInSet(column="country",
            value_set=["México","Colombia","España","Argentina","Chile"]),
        lambda: gxe.ExpectColumnValuesToBeInSet(column="plan",
            value_set=["free","basic","pro","enterprise"]),
        lambda: gxe.ExpectColumnValuesToBeBetween(column="monthly_spend", min_value=0),
        lambda: gxe.ExpectColumnValuesToBeBetween(column="nps_score", min_value=0, max_value=10),
        lambda: gxe.ExpectColumnMeanToBeBetween(column="age", min_value=25, max_value=60),
        lambda: gxe.ExpectColumnStdevToBeBetween(column="monthly_spend", min_value=0, max_value=500),
        lambda: gxe.ExpectColumnMedianToBeBetween(column="age", min_value=20, max_value=70),
        lambda: gxe.ExpectColumnProportionOfUniqueValuesToBeBetween(
            column="plan", min_value=0.0, max_value=0.5),
    ]

result_clean = run_suite(df_clean, ventas_exp_factories())
result_dirty = run_suite(df_dirty, ventas_exp_factories())
result_users = run_suite(df_users, users_exp_factories())

def serialize(result):
    stats = result.statistics
    rows = []
    for r in result.results:
        ec = r.expectation_config
        kw = dict(ec.kwargs)
        col = kw.pop("column", "TABLE")
        rows.append({
            "expectation_type": ec.type,
            "column": col,
            "kwargs": {k: (list(v) if hasattr(v,"__iter__") and not isinstance(v,str) else v)
                       for k,v in kw.items()},
            "success": r.success,
            "result": {k: (float(v) if isinstance(v,(np.floating,np.integer)) else v)
                       for k,v in (r.result or {}).items() if not isinstance(v,dict)},
        })
    return {
        "success": result.success,
        "statistics": {
            "evaluated":    stats.get("evaluated_expectations",0),
            "successful":   stats.get("successful_expectations",0),
            "unsuccessful": stats.get("unsuccessful_expectations",0),
            "success_pct":  round(stats.get("success_percent",0),1),
        },
        "results": rows,
    }

report = {
    "ventas_limpio": serialize(result_clean),
    "ventas_sucios":  serialize(result_dirty),
    "usuarios":       serialize(result_users),
}

with open("/home/claude/ge_guide/outputs/validation_report.json","w",encoding="utf-8") as f:
    json.dump(report, f, ensure_ascii=False, indent=2)

print("✅ Reporte generado")
for k,v in report.items():
    s=v["statistics"]
    print(f"  {'✅' if v['success'] else '❌'} {k}: {s['successful']}/{s['evaluated']} ({s['success_pct']}%)")
